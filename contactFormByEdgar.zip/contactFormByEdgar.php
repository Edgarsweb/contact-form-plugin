<?php 
/**
 * Plugin Name: Contact Form By Edgar
 * Author: Edgar Hovhannisyan
 * Plugin URI: http://edgarsblog.com/
 * Description: Contact Form Plugin
 */


add_action('admin_menu', 'test_plugin_setup_menu');
 
function test_plugin_setup_menu(){
    add_menu_page( 'Test Plugin Page', 'Contact Form by Edgar', 'manage_options', 'test-plugin', 'test_init' );
}
 
function test_init(){
    echo "<h2>Shortcode for contact form: [edxweb_form]</h2>";
    echo "<p>You will receive mail notifications to your admin email, so please make sure it has been set to the email address, you want to get notifications on</p>";

}




 function edxweb_form_plugin()
 
 
 {
   

    $content = '';
    $content .= '<h2>Contact us</h2>';
   

    $content .= '<form method="post" action="http://www.juntal.xyz/thank-you/">';   

    $content .= '<br /><input type="text" name="your_name" class="form-control" placeholder="Enter your name" />'; 

    $content .= '<br /><input type="email" name="your_email" class="form-control" placeholder="Enter your email" />'; 

   //  $content .= '<br /><textarea name="your_comments" class="form-control" placeholder="Enter your message"></textarea>';  

    $content .= '<br /><input type="submit" name="contact_form_submit" value="Send"   />';
    
    $content .= '</form>';  
    

  

    return $content;

 }

 add_shortcode('edxweb_form', 'edxweb_form_plugin');


 function edxweb_form_capture ()
 {
    if(isset($_POST['contact_form_submit']));

    {   
        $name = sanitize_text_field($_POST['your_name']);
        $email = sanitize_text_field($_POST['your_email']);
        $messageField = sanitize_textarea_field($_POST['your_comments']);

        $to = get_bloginfo( 'admin_email' );
        $subject = 'Test form submission';
        $message = ''.$name.'-'.$email.'-'.$messageField;

        wp_mail($to, $subject, $message);
    }

    
 }

 

 add_action('wp_head', 'edxweb_form_capture');

 




 



