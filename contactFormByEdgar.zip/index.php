<?php 
// Silence is golden 

?>